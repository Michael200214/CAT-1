package com.example.myapplication_health_care;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyApplicationHealthCareApplicationTests {

    @Test
    void contextLoads() {
    }

}
